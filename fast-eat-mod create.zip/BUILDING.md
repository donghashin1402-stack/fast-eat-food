# Build the Fabric mod JAR on GitHub

1. Upload/push the contents of this project folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Fabric Mod** and click **Run workflow** (or push a commit to trigger it automatically).
4. Open the completed workflow run and download the **fast-eat-mod-jar** artifact.
5. Extract the downloaded artifact ZIP and place `fast-eat-mod-1.0.0.jar` in your Minecraft `mods` folder.

The workflow uses Java 25 and Gradle 9.2.1. A successful build only confirms compilation/package creation; verify the mod in Minecraft 26.3 with the matching Fabric Loader and Fabric API versions.
